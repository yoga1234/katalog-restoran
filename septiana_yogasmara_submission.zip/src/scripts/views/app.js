class App {
  constructor ({ button, drawer, content }) {
    this._button = button
    this._drawer = drawer
    this._content = content
  }

  _initialAppShell () {
    // initial drawer
    // initialization another component
  }
};

export default App
